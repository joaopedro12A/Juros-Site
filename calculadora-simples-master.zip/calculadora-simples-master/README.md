# Calculadora simples - Senhor Programador

Calculadora desenvolvida com JavaScript

Esse código é do [tutorial feito no meu canal do YouTube](https://www.youtube.com/watch?v=30AWy90GMJc&t=2s&ab_channel=SenhorProgramador)
